<?php

use Illuminate\Support\Str;

$centralDatabase = env('DB_CENTRAL_DATABASE') ?: database_path('central.sqlite');

return [
    'default' => env('DB_CONNECTION', 'central'),
    'connections' => [
        'central' => env('DB_CENTRAL_DRIVER', 'sqlite') === 'sqlite'
            ? [
                'driver' => 'sqlite',
                'url' => null,
                'database' => $centralDatabase,
                'prefix' => '',
                'foreign_key_constraints' => true,
                'busy_timeout' => null,
                'journal_mode' => null,
                'synchronous' => null,
            ]
            : [
                'driver' => env('DB_CENTRAL_DRIVER', 'mysql'),
                'url' => null,
                'host' => env('DB_CENTRAL_HOST', '127.0.0.1'),
                'port' => env('DB_CENTRAL_PORT', '3306'),
                'database' => env('DB_CENTRAL_DATABASE', 'dejiaohui_central'),
                'username' => env('DB_CENTRAL_USERNAME', 'root'),
                'password' => env('DB_CENTRAL_PASSWORD', ''),
                'unix_socket' => env('DB_CENTRAL_SOCKET', ''),
                'charset' => 'utf8mb4',
                'collation' => 'utf8mb4_unicode_ci',
                'prefix' => '',
                'prefix_indexes' => true,
                'strict' => true,
                'engine' => null,
            ],
        'tenant' => [
            'driver' => 'sqlite',
            'url' => null,
            'database' => database_path('tenants/placeholder.sqlite'),
            'prefix' => '',
            'foreign_key_constraints' => true,
        ],
    ],
    'migrations' => [
        'table' => 'migrations',
        'update_date_on_publish' => true,
    ],
    'redis' => [
        'client' => env('REDIS_CLIENT', 'phpredis'),
        'options' => [
            'cluster' => env('REDIS_CLUSTER', 'redis'),
            'prefix' => env('REDIS_PREFIX', Str::slug(env('APP_NAME', 'siyadi'), '_').'_database_'),
        ],
        'default' => [
            'url' => env('REDIS_URL'),
            'host' => env('REDIS_HOST', '127.0.0.1'),
            'username' => env('REDIS_USERNAME'),
            'password' => env('REDIS_PASSWORD'),
            'port' => env('REDIS_PORT', '6379'),
            'database' => env('REDIS_DB', '0'),
        ],
    ],
];
