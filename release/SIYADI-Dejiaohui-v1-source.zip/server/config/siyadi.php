<?php

return [
    'modules' => [
        'members' => [
            'title' => 'Anggota', 'singular' => 'Anggota', 'table' => 'members', 'icon' => '👥',
            'search' => ['member_no', 'name', 'phone'],
            'columns' => ['member_no', 'name', 'phone', 'status'],
            'fields' => [
                'member_no' => ['label' => 'Nomor Anggota', 'type' => 'text', 'rules' => ['required','string','max:50']],
                'name' => ['label' => 'Nama Lengkap', 'type' => 'text', 'rules' => ['required','string','max:150']],
                'chinese_name' => ['label' => 'Nama Tionghoa', 'type' => 'text', 'rules' => ['nullable','string','max:150']],
                'phone' => ['label' => 'Telepon', 'type' => 'text', 'rules' => ['nullable','string','max:30']],
                'address' => ['label' => 'Alamat', 'type' => 'textarea', 'rules' => ['nullable','string']],
                'join_date' => ['label' => 'Tanggal Bergabung', 'type' => 'date', 'rules' => ['nullable','date']],
                'status' => ['label' => 'Status', 'type' => 'select', 'options' => ['Aktif','Tidak Aktif'], 'rules' => ['required','string']],
            ],
        ],
        'donations' => [
            'title' => 'Donasi', 'singular' => 'Donasi', 'table' => 'donations', 'icon' => '💝',
            'search' => ['receipt_no', 'donor_name', 'purpose'],
            'columns' => ['receipt_no', 'donor_name', 'donation_date', 'amount', 'status'],
            'fields' => [
                'receipt_no' => ['label' => 'Nomor Kuitansi', 'type' => 'text', 'rules' => ['required','string','max:50']],
                'donor_name' => ['label' => 'Nama Donatur', 'type' => 'text', 'rules' => ['required','string','max:150']],
                'donation_date' => ['label' => 'Tanggal', 'type' => 'date', 'rules' => ['required','date']],
                'amount' => ['label' => 'Nominal', 'type' => 'number', 'rules' => ['required','numeric','min:0']],
                'payment_method' => ['label' => 'Metode', 'type' => 'select', 'options' => ['Tunai','Transfer Bank','QRIS','Lainnya'], 'rules' => ['required','string']],
                'purpose' => ['label' => 'Tujuan Donasi', 'type' => 'text', 'rules' => ['nullable','string','max:150']],
                'status' => ['label' => 'Status', 'type' => 'select', 'options' => ['Menunggu Verifikasi','Terverifikasi','Dibatalkan'], 'rules' => ['required','string']],
            ],
        ],
        'programs' => [
            'title' => 'Program Sosial', 'singular' => 'Program', 'table' => 'social_programs', 'icon' => '🌏',
            'search' => ['program_code', 'name', 'category', 'location'],
            'columns' => ['program_code', 'name', 'start_date', 'location', 'status'],
            'fields' => [
                'program_code' => ['label' => 'Kode Program', 'type' => 'text', 'rules' => ['required','string','max:50']],
                'name' => ['label' => 'Nama Program', 'type' => 'text', 'rules' => ['required','string','max:150']],
                'category' => ['label' => 'Kategori', 'type' => 'select', 'options' => ['Pembagian Sembako','Donor Darah','Pendidikan Moral','Bantuan Bencana','Pemeriksaan Kesehatan','Pelestarian Budaya','Lainnya'], 'rules' => ['required','string']],
                'start_date' => ['label' => 'Tanggal Mulai', 'type' => 'date', 'rules' => ['required','date']],
                'location' => ['label' => 'Lokasi', 'type' => 'text', 'rules' => ['nullable','string','max:190']],
                'target_beneficiaries' => ['label' => 'Target Penerima', 'type' => 'number', 'rules' => ['nullable','integer','min:0']],
                'budget' => ['label' => 'Anggaran', 'type' => 'number', 'rules' => ['nullable','numeric','min:0']],
                'status' => ['label' => 'Status', 'type' => 'select', 'options' => ['Direncanakan','Berjalan','Selesai','Dibatalkan'], 'rules' => ['required','string']],
                'description' => ['label' => 'Deskripsi', 'type' => 'textarea', 'rules' => ['nullable','string']],
            ],
        ],
        'beneficiaries' => [
            'title' => 'Penerima Manfaat', 'singular' => 'Penerima', 'table' => 'beneficiaries', 'icon' => '🫶',
            'search' => ['beneficiary_no', 'name', 'need_type'],
            'columns' => ['beneficiary_no', 'name', 'need_type', 'verification_status'],
            'fields' => [
                'beneficiary_no' => ['label' => 'Nomor Penerima', 'type' => 'text', 'rules' => ['required','string','max:50']],
                'name' => ['label' => 'Nama', 'type' => 'text', 'rules' => ['required','string','max:150']],
                'phone' => ['label' => 'Telepon', 'type' => 'text', 'rules' => ['nullable','string','max:30']],
                'address' => ['label' => 'Alamat', 'type' => 'textarea', 'rules' => ['nullable','string']],
                'need_type' => ['label' => 'Jenis Kebutuhan', 'type' => 'text', 'rules' => ['required','string','max:150']],
                'verification_status' => ['label' => 'Verifikasi', 'type' => 'select', 'options' => ['Belum Disurvei','Disurvei','Terverifikasi','Ditolak'], 'rules' => ['required','string']],
            ],
        ],
        'finances' => [
            'title' => 'Keuangan', 'singular' => 'Transaksi', 'table' => 'finances', 'icon' => '💰',
            'search' => ['transaction_no', 'category', 'description'],
            'columns' => ['transaction_no', 'transaction_date', 'type', 'category', 'amount'],
            'fields' => [
                'transaction_no' => ['label' => 'Nomor Transaksi', 'type' => 'text', 'rules' => ['required','string','max:50']],
                'transaction_date' => ['label' => 'Tanggal', 'type' => 'date', 'rules' => ['required','date']],
                'type' => ['label' => 'Jenis', 'type' => 'select', 'options' => ['Pemasukan','Pengeluaran'], 'rules' => ['required','string']],
                'category' => ['label' => 'Kategori', 'type' => 'text', 'rules' => ['required','string','max:150']],
                'description' => ['label' => 'Keterangan', 'type' => 'textarea', 'rules' => ['required','string']],
                'amount' => ['label' => 'Nominal', 'type' => 'number', 'rules' => ['required','numeric','min:0']],
            ],
        ],
    ],
];
