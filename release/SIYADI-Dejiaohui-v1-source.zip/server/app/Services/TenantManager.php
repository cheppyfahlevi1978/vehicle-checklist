<?php

namespace App\Services;

use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\DB;
use stdClass;

class TenantManager
{
    public function resolve(?string $code, string $host): ?stdClass
    {
        try {
            $query = DB::connection('central')->table('branches')->where('is_active', true);
            $byDomain = (clone $query)->where('domain', strtolower($host))->first();
            if ($byDomain) return $byDomain;
            return $code ? $query->whereRaw('UPPER(code) = ?', [strtoupper($code)])->first() : null;
        } catch (\Throwable) {
            return null;
        }
    }

    public function configure(stdClass $branch): void
    {
        $database = $branch->database_name;
        if (! str_starts_with($database, DIRECTORY_SEPARATOR)) $database = base_path($database);

        Config::set('database.connections.tenant', [
            'driver' => 'sqlite', 'url' => null, 'database' => $database,
            'prefix' => '', 'foreign_key_constraints' => true,
        ]);
        DB::purge('tenant');
        DB::connection('tenant')->getPdo();
        app()->instance('tenant.branch', $branch);
    }
}
