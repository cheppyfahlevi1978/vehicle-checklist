<?php
namespace App\Http\Middleware;
use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
class NationalAuthenticated
{
    public function handle(Request $request, Closure $next): Response
    {
        return session('national_user') ? $next($request) : redirect()->route('national.login');
    }
}
