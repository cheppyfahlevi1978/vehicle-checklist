<?php

namespace App\Http\Middleware;

use App\Services\TenantManager;
use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class ResolveTenant
{
    public function __construct(private readonly TenantManager $tenants) {}

    public function handle(Request $request, Closure $next): Response
    {
        if ($request->is('national*') || $request->is('up')) return $next($request);

        $code = $request->query('branch') ?: session('branch_code') ?: env('DEFAULT_BRANCH_CODE');
        $branch = $this->tenants->resolve($code, strtolower($request->getHost()));

        if (! $branch) {
            return response('Database belum terpasang. Jalankan: php artisan system:install-demo --force', 503);
        }

        $this->tenants->configure($branch);
        session(['branch_code' => $branch->code]);
        return $next($request);
    }
}
