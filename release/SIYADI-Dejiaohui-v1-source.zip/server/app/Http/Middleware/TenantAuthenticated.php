<?php
namespace App\Http\Middleware;
use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
class TenantAuthenticated
{
    public function handle(Request $request, Closure $next): Response
    {
        $branch = app('tenant.branch');
        $user = session('tenant_user');
        if (! $user || ($user['branch_code'] ?? null) !== $branch->code) return redirect()->route('login');
        return $next($request);
    }
}
