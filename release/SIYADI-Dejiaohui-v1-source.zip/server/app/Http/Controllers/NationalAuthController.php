<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
class NationalAuthController extends Controller
{
    public function show() { return view('national.login'); }
    public function login(Request $request)
    {
        $data = $request->validate(['email' => ['required','email'], 'password' => ['required','string']]);
        $user = DB::connection('central')->table('national_users')->where('email', strtolower($data['email']))->where('is_active', true)->first();
        if (! $user || ! Hash::check($data['password'], $user->password)) return back()->withInput()->with('error','Email atau password nasional tidak sesuai.');
        $request->session()->regenerate();
        session(['national_user' => ['id'=>$user->id,'name'=>$user->name,'role'=>$user->role]]);
        return redirect()->route('national.dashboard');
    }
    public function logout(Request $request)
    {
        $request->session()->forget('national_user');
        $request->session()->regenerateToken();
        return redirect()->route('national.login');
    }
}
