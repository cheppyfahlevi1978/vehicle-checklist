<?php
namespace App\Http\Controllers;
use Illuminate\Support\Facades\DB;
class DashboardController extends Controller
{
    public function index()
    {
        $db = DB::connection('tenant');
        $stats = [
            'members'=>$db->table('members')->where('status','Aktif')->count(),
            'programs'=>$db->table('social_programs')->count(),
            'beneficiaries'=>$db->table('beneficiaries')->count(),
            'donations'=>(float)$db->table('donations')->where('status','Terverifikasi')->sum('amount'),
            'income'=>(float)$db->table('finances')->where('type','Pemasukan')->sum('amount'),
            'expense'=>(float)$db->table('finances')->where('type','Pengeluaran')->sum('amount'),
        ];
        $stats['balance']=$stats['income']-$stats['expense'];
        return view('dashboard', compact('stats'));
    }
}
