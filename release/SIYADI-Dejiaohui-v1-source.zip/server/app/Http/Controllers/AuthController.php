<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
class AuthController extends Controller
{
    public function show() { return view('auth.login'); }
    public function login(Request $request)
    {
        $data = $request->validate(['email' => ['required','email'], 'password' => ['required','string']]);
        $user = DB::connection('tenant')->table('users')->where('email', strtolower($data['email']))->where('is_active', true)->first();
        if (! $user || ! Hash::check($data['password'], $user->password)) return back()->withInput()->with('error','Email atau password tidak sesuai.');
        $branch = app('tenant.branch');
        $request->session()->regenerate();
        session(['tenant_user' => ['id'=>$user->id,'name'=>$user->name,'role'=>$user->role,'branch_code'=>$branch->code]]);
        return redirect()->route('dashboard');
    }
    public function logout(Request $request)
    {
        $request->session()->forget('tenant_user');
        $request->session()->regenerateToken();
        return redirect()->route('login');
    }
}
