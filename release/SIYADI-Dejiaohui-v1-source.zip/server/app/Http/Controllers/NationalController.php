<?php
namespace App\Http\Controllers;
use App\Services\TenantManager;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Hash;
class NationalController extends Controller
{
    public function dashboard(){ $branches=DB::connection('central')->table('branches')->orderBy('name')->get(); return view('national.dashboard',compact('branches')); }
    public function store(Request $request,TenantManager $tenants)
    {
        $data=$request->validate(['code'=>['required','string','max:10'],'name'=>['required','string','max:150'],'city'=>['nullable','string','max:100'],'province'=>['nullable','string','max:100']]);
        $code=strtoupper($data['code']);$relative='database/tenants/'.strtolower($code).'.sqlite';$absolute=base_path($relative);File::ensureDirectoryExists(dirname($absolute));if(!File::exists($absolute))File::put($absolute,'');
        $id=DB::connection('central')->table('branches')->insertGetId(['code'=>$code,'name'=>$data['name'],'city'=>$data['city']??null,'province'=>$data['province']??null,'domain'=>null,'database_name'=>$relative,'is_active'=>true,'created_at'=>now(),'updated_at'=>now()]);
        $branch=DB::connection('central')->table('branches')->find($id);$tenants->configure($branch);
        Artisan::call('migrate',['--database'=>'tenant','--path'=>'database/migrations/tenant','--force'=>true]);
        DB::connection('tenant')->table('users')->insert(['name'=>'Administrator '.$data['name'],'email'=>'admin.'.strtolower($code).'@dejiaohui.id','password'=>Hash::make('Cabang123!'),'role'=>'Administrator Cabang','is_active'=>true,'created_at'=>now(),'updated_at'=>now()]);
        return back()->with('success','Cabang dibuat. Login awal: admin.'.strtolower($code).'@dejiaohui.id / Cabang123!');
    }
}
