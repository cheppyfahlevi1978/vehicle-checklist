<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
class ResourceController extends Controller
{
    private function def(string $module): array { $d=config("siyadi.modules.$module"); abort_unless(is_array($d),404); return $d; }
    public function index(Request $request,string $module)
    {
        $definition=$this->def($module); $q=DB::connection('tenant')->table($definition['table']);
        if($s=trim((string)$request->query('q'))){$q->where(function($b)use($definition,$s){foreach($definition['search'] as $i=>$f){$m=$i?'orWhere':'where';$b->{$m}($f,'like',"%$s%");}});} 
        $rows=$q->orderByDesc('id')->simplePaginate(15)->withQueryString(); return view('resources.index',compact('module','definition','rows'));
    }
    public function create(string $module){$definition=$this->def($module);$row=null;return view('resources.form',compact('module','definition','row'));}
    public function store(Request $r,string $module){$d=$this->def($module);$data=$r->validate($this->rules($d));$data['created_at']=now();$data['updated_at']=now();DB::connection('tenant')->table($d['table'])->insert($data);return redirect()->route('resources.index',$module)->with('success','Data berhasil ditambahkan.');}
    public function edit(string $module,int $id){$definition=$this->def($module);$row=DB::connection('tenant')->table($definition['table'])->find($id);abort_unless($row,404);return view('resources.form',compact('module','definition','row'));}
    public function update(Request $r,string $module,int $id){$d=$this->def($module);$data=$r->validate($this->rules($d));$data['updated_at']=now();DB::connection('tenant')->table($d['table'])->where('id',$id)->update($data);return redirect()->route('resources.index',$module)->with('success','Data berhasil diperbarui.');}
    public function destroy(string $module,int $id){$d=$this->def($module);DB::connection('tenant')->table($d['table'])->where('id',$id)->delete();return back()->with('success','Data berhasil dihapus.');}
    private function rules(array $d):array{$r=[];foreach($d['fields'] as $f=>$m)$r[$f]=$m['rules']??['nullable'];return $r;}
}
