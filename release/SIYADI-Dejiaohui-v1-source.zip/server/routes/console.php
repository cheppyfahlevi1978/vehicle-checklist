<?php
use App\Services\TenantManager;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Hash;
Artisan::command('system:install-demo {--force}',function(){
    File::ensureDirectoryExists(database_path('tenants'));File::ensureDirectoryExists(storage_path('framework/cache/data'));File::ensureDirectoryExists(storage_path('framework/sessions'));File::ensureDirectoryExists(storage_path('framework/views'));
    $central=config('database.connections.central.database');if(!File::exists($central))File::put($central,'');
    Artisan::call('migrate',['--database'=>'central','--path'=>'database/migrations/central','--force'=>true],$this->output);
    DB::connection('central')->table('national_users')->updateOrInsert(['email'=>'admin@dejiaohui.id'],['name'=>'Administrator Nasional','password'=>Hash::make('Admin123!'),'role'=>'Super Admin Nasional','is_active'=>true,'created_at'=>now(),'updated_at'=>now()]);
    $rel='database/tenants/sby.sqlite';$abs=base_path($rel);if(!File::exists($abs))File::put($abs,'');
    DB::connection('central')->table('branches')->updateOrInsert(['code'=>'SBY'],['name'=>'Yayasan Dejiaohui Surabaya','city'=>'Surabaya','province'=>'Jawa Timur','domain'=>null,'database_name'=>$rel,'is_active'=>true,'created_at'=>now(),'updated_at'=>now()]);
    $branch=DB::connection('central')->table('branches')->where('code','SBY')->first();app(TenantManager::class)->configure($branch);
    Artisan::call('migrate',['--database'=>'tenant','--path'=>'database/migrations/tenant','--force'=>true],$this->output);
    DB::connection('tenant')->table('users')->updateOrInsert(['email'=>'admin.sby@dejiaohui.id'],['name'=>'Administrator Cabang Surabaya','password'=>Hash::make('Cabang123!'),'role'=>'Administrator Cabang','is_active'=>true,'created_at'=>now(),'updated_at'=>now()]);
    if(DB::connection('tenant')->table('members')->count()===0){DB::connection('tenant')->table('members')->insert(['member_no'=>'SBY-AGT-000001','name'=>'Anggota Contoh','chinese_name'=>null,'phone'=>'081234567890','address'=>'Surabaya','join_date'=>now()->format('Y-m-d'),'status'=>'Aktif','created_at'=>now(),'updated_at'=>now()]);}
    $this->info('Instalasi selesai. Cabang: admin.sby@dejiaohui.id / Cabang123! | Nasional: admin@dejiaohui.id / Admin123!');
})->purpose('Memasang database pusat dan cabang pilot Surabaya.');
