<?php
use App\Http\Controllers\AuthController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\NationalAuthController;
use App\Http\Controllers\NationalController;
use App\Http\Controllers\ResourceController;
use Illuminate\Support\Facades\Route;
Route::get('/',fn()=>redirect()->route('dashboard'));
Route::get('/login',[AuthController::class,'show'])->name('login');
Route::post('/login',[AuthController::class,'login'])->name('login.submit');
Route::post('/logout',[AuthController::class,'logout'])->name('logout');
Route::middleware('tenant.auth')->group(function(){
    Route::get('/dashboard',[DashboardController::class,'index'])->name('dashboard');
    Route::get('/data/{module}',[ResourceController::class,'index'])->name('resources.index');
    Route::get('/data/{module}/create',[ResourceController::class,'create'])->name('resources.create');
    Route::post('/data/{module}',[ResourceController::class,'store'])->name('resources.store');
    Route::get('/data/{module}/{id}/edit',[ResourceController::class,'edit'])->name('resources.edit');
    Route::put('/data/{module}/{id}',[ResourceController::class,'update'])->name('resources.update');
    Route::delete('/data/{module}/{id}',[ResourceController::class,'destroy'])->name('resources.destroy');
});
Route::prefix('national')->name('national.')->group(function(){
    Route::get('/login',[NationalAuthController::class,'show'])->name('login');Route::post('/login',[NationalAuthController::class,'login'])->name('login.submit');Route::post('/logout',[NationalAuthController::class,'logout'])->name('logout');
    Route::middleware('national.auth')->group(function(){Route::get('/dashboard',[NationalController::class,'dashboard'])->name('dashboard');Route::post('/branches',[NationalController::class,'store'])->name('branches.store');});
});
