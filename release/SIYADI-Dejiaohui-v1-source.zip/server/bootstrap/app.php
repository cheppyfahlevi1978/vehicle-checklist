<?php

use App\Http\Middleware\NationalAuthenticated;
use App\Http\Middleware\ResolveTenant;
use App\Http\Middleware\TenantAuthenticated;
use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(web: __DIR__.'/../routes/web.php', commands: __DIR__.'/../routes/console.php', health: '/up')
    ->withMiddleware(function (Middleware $middleware): void {
        $middleware->appendToGroup('web', [ResolveTenant::class]);
        $middleware->alias(['tenant.auth' => TenantAuthenticated::class, 'national.auth' => NationalAuthenticated::class]);
    })
    ->withExceptions(function (Exceptions $exceptions): void {})
    ->create();
