# SIYADI Dejiaohui Indonesia — Pilot v1

Arsitektur mengikuti pola aplikasi RESTO:

- backend Laravel di hosting;
- satu database pusat;
- database SQLite tersendiri untuk setiap cabang;
- satu APK Android WebView yang mengakses `https://yayasan.ias4u.my.id`.

## Instalasi Domainesia

Ekstrak source ke:

```text
/home/iasumyid/yayasan.ias4u.my.id
```

Document Root:

```text
/home/iasumyid/yayasan.ias4u.my.id/public
```

Jalankan:

```bash
cd /home/iasumyid/yayasan.ias4u.my.id
composer install --no-dev --optimize-autoloader
cp .env.example .env
php artisan key:generate --force
mkdir -p database/tenants
php artisan system:install-demo --force
chmod -R 775 storage bootstrap/cache database
php artisan optimize:clear
```

Pastikan PHP 8.3+, `pdo_sqlite`, dan `sqlite3` aktif.

## Login pilot

Cabang Surabaya:

- URL: `/login`
- Email: `admin.sby@dejiaohui.id`
- Password: `Cabang123!`

Portal nasional:

- URL: `/national/login`
- Email: `admin@dejiaohui.id`
- Password: `Admin123!`

Ganti password demo setelah pengujian.
